class Report:

    def __init__(self, past):
        self.past = past
        self.orders = 0
        self.volume = 0
        self.gain = 0
        self.loss = 0
        self.list = []
